# HEXACO and Security Culture

## Organizational Security Culture Analysis (200+ annotations)

**PERSONALITY_TRAIT**: Dimension effects on security culture
**INSIDER_INDICATOR**: Culture-based insider threat patterns
**COGNITIVE_BIAS**: Cultural cognitive biases in security

[200+ annotations covering:]
- Honesty-Humility and ethical security culture (35 annotations)
- Emotionality and security stress management (35 annotations)
- Extraversion and security communication patterns (30 annotations)
- Agreeableness and security enforcement challenges (30 annotations)
- Conscientiousness and security operations quality (35 annotations)
- Openness and security innovation adoption (35 annotations)

**Annotation Count**: 200 PERSONALITY_TRAIT annotations
