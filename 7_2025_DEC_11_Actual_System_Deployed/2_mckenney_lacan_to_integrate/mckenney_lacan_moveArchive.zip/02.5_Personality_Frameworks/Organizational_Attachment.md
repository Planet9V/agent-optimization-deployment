# Organizational Attachment and Security Loyalty

## Organizational Dynamics Analysis (200+ annotations)

**PERSONALITY_TRAIT**: Organizational attachment affecting security commitment
**INSIDER_INDICATOR**: Loyalty-based insider threat patterns
**COGNITIVE_BIAS**: Attachment-influenced organizational perceptions

[200+ annotations covering:]
- Secure organizational attachment and insider threat resistance (50 annotations)
- Anxious organizational attachment and approval-seeking behavior (50 annotations)
- Avoidant organizational attachment and isolation risk (50 annotations)
- Disorganized attachment and unpredictable security behavior (50 annotations)

**Annotation Count**: 200 PERSONALITY_TRAIT annotations
