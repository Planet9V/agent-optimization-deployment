Spec driven development** **

Alternatively, you can add configuration in mcp.json:

{

**    **"servers": {

**        **"spec-driven": {

**            **"command": "npx",

**            **"args": [

**                **"-y",

**                **"mcp-server-spec-driven-development@latest"

**            **]

**        **}

**    **}

}

**Cursor, Claude Code**

[](https://github.com/formulahendry/mcp-server-spec-driven-development#cursor-claude-code)

Install the MCP server in Cursor using below button:

Alternatively, you can add configuration in mcp.json:

{

**    **"mcpServers": {

**        **"spec-driven": {

**            **"command": "npx",

**            **"args": [

**                **"-y",

**                **"mcp-server-spec-driven-development@latest"

**            **]

**        **}

**    **}

}

📋** Available Prompts**

[](https://github.com/formulahendry/mcp-server-spec-driven-development#-available-prompts)

**1. Generate Requirements Document**

[](https://github.com/formulahendry/mcp-server-spec-driven-development#1-generate-requirements-document)

* **Name** : generate-requirements
* **Description** : Generate requirements.md using EARS format
* **Input** : High-level requirements of the application. Example: 'A Vue.js todo application with task creation, completion tracking, and local storage persistence'
* **Output** : Structured requirements document in specs/requirements.md

**2. Generate Design from Requirements**

[](https://github.com/formulahendry/mcp-server-spec-driven-development#2-generate-design-from-requirements)

* **Name** : generate-design-from-requirements
* **Description** : Generate design.md from requirements.md
* **Input** : Reads from specs/requirements.md
* **Output** : Design document in specs/design.md

**3. Generate Code from Design**

[](https://github.com/formulahendry/mcp-server-spec-driven-development#3-generate-code-from-design)

* **Name** : generate-code-from-design
* **Description** : Generate code from design.md
* **Input** : Reads from specs/design.md
* **Output** : Implementation code in the root folder

📖** Workflow Example**

[](https://github.com/formulahendry/mcp-server-spec-driven-development#-workflow-example)

1. **Start with Requirements** : Use the generate-requirements prompt with your initial requirements text
2. **Create Design** : Use generate-design-from-requirements to create a design document based on your requirements
3. **Generate Code** : Use generate-code-from-design to generate implementation code from your design

This creates a traceable path from requirements through design to implementation, ensuring consistency and completeness in your development process.

CENSYS_API_KEY=censys_FpyqAt93_BJVoNqeEvV392sGYD2w8GZbX

## OPENROUTER_API_KEY=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

## Github key = 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

# OPENAI_API_KEY= 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

This is current as of 10-19-2025

#Codacity Key

CODACITY_API_KEY=bYwH93DUKLJBT9n31XF3

#Firecrawl Key

FIRECRAWL_API_KEY=fc-57e461abf155483eae3237e0af57e841

#Hugging Face

HUGGINGFACE_API_KEY=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

#ElevenLabs (Generative AI & RAG)

ElevenLabs_API_KEY=sk_8dfedb4846c5dd9571469d46a991b00f38af60df06c8862d

#Speechify (Text-to-Speech)

Speechify_API_KEY=o0WUsY2374J3piGs8C5wqeJ8vwHx37T7F0ndsEJB5fw=

# Jina AI (Advanced Embeddings & Reranking)

JINA_API_KEY=jina_1a1eace3ff45463b834aacf79ae15677BWVw8TNEoezGvjjcniDJOKDJ9UyS

# =============================================================================

# RESEARCH & DATA PROVIDERS (OPTIONAL)

# =============================================================================

# Perplexity AI (Knowledge Graph & Search)

PERPLEXITY_API_KEY=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

# NewsAPI (Real-time News)

NEWSAPI_KEY=5a377626312d4747ab0504268be4c2d2

# Tavily (Web Search & Intelligence)

TAVILY_API_KEY=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

# Google Scholar API (Academic Research)

GOOGLE_SCHOLAR_API_KEY=67621e216ffeed0c2c20f069

#Brave Search (Web Search)

BRAVE_API_KEY=BSAP0LqtBpuCz19UbWd_SF6BCSTgQbD

# DeepSeek (Reasoning & Analysis)

DEEPSEEK_API_KEY=sk-1de22b1c81fd4f3c917689334ee8d256

# Google AI Studio (Gemini Models)

GOOGLE_AI_API_KEY=AIzaSyCMGPNIe6hWBqeRBWoZVB6FxS0PsIr7KKI

#DeepseekWiki

DEEPWIKI_API_KEY=sk-60f848b4d3ba42a496be7209f6b6f7d3
