  
claude \--continue \--dangerously-skip-permissions

\#\# CReds  
docker n8n  
pass \= KansasCity2024$

UBUNTU   
jim  
KansasCity2024$

\#\#\# API Keys

VULNCHECK\_API\_KEY=vulncheck\_417014ea13c166789a577b3b2f8cc87ddac87cb150c389c9f61df53478fc797f

Deepseek\_API\_KEY=sk-e652aae11e4b437b84ccf7bc27fac243  
Openapi\_API\_KEY=sk-proj-VitYxNmBXlcm8R\_S7KJCNmoHY6\_lfK1hCF4zq4bB7xgCAAo4k6KG-6NRVQkDqFK8pm0GBBx6eFT3BlbkFJ5xP8PsRKRKwO6NDbV0hE-jJi07EjlWYPCcF1RMs3H9ItS5AyuxfyZ2mRRFZiOruWfrmIOmLWUA  
Openrouter\_API\_KEY=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  
Openrouter\_API\_KEY\_FOR\_ROO\_FREE=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

NIST\_NVD\_API\_KEY=534786f5-5359-40b8-8e54-b28eb742de7c   
VULNCHECK\_API\_KEY=vulncheck\_d50b2321719330fa9fd39437b61bab52d729bfa093b8f15fe97b4db4349f584c

BRAVE\_API\_KEY=BSAP0LqtBpuCz19UbWd\_SF6BCSTgQbD

Google API Scholar API \=  67621e216ffeed0c2c20f069

NEWS\_API\_KEY=5a377626312d4747ab0504268be4c2d2

OPENSPG\_QDRANT\_API\_KEY=deqUCd5v5tL3NNTlcY3tXuPX+9vNZ7P1NMt/WlBUOZQ=

APIs TO USE:  
       \- NVD\_API\_KEY: https://services.nvd.nist.gov/rest/json/cves/2.0

       \- FIRST.org EPSS: https://api.first.org/data/v1/epss  
       \- API Key: 534786f5-5359-40b8-8e54-b28eb742de7c

\#\#\#  
https://console.vulncheck.com/api

open-sgp-qdrant on local docker   
     \# Qdrant Vector Database Configuration  
     \# Generated: 2025-10-31  
     \# Purpose: Environment variables for docker-compose.qdrant.yml  
     \# Security: API Key Authentication  
     QDRANT\_API\_KEY=deqUCd5v5tL3NNTlcY3tXuPX+9vNZ7P1NMt/WlBUOZQ=  
     \# Resource Limits  
     QDRANT\_MEMORY\_LIMIT=4G  
     QDRANT\_MEMORY\_RESERVATION=2G  
     … \+18 lines (ctrl+o to expand)

openspg-neo4j  
user \= neo4j  
pass \= neo4j@openspg

\#\# Free Online:  
Model: deepseek/deepseek-r1-0528:free:online  
Model: mistralai/mistral-7b-instruct:free:online  
Model: meta-llama/llama-3.3-70b-instruct:free:online

\#\# Free   
google/gemini-2.5-flash-lite-preview-09-2025  
minimax/minimax-m2:free  
deepseek/deepseek-v3.1-terminus  
cognitivecomputations/dolphin3.0-mistral-24b

\#\# Use SWARM w/QUADRANT  
it is critical, it is vital the you always use The swarm coordination with Qdrant vector memory is tracking all agent   
activities, referencing key data and storing checkpoints for state preservation, 

MISTRAL\_API\_KEY=HxtQLssYgEsSUvJ6v2UUNbVvuSECU1L

TAVILY\_API\_KEY=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

BRAVE\_API\_KEY=BSAP0LqtBpuCz19UbWd\_SF6BCSTgQbD

Google API Scholar API \=  67621e216ffeed0c2c20f069

NEWS\_API\_KEY=5a377626312d4747ab0504268be4c2d2  
GROQ\_API\_KEY=gsk\_qdD9unbwxLMilsqXNDJlWGdyb3FYAvdI7JiyXrTKEZtl3N8tjkCy

https://platform.securityscorecard.io/

Login  \= jim@planet9ventures.ai  
Password \= randomsecuritypassword100$R

\#\# API Documentation  
\# SecurityTrails API™

Data for Security companies, researchers and teams. Fast, always up cyber security API that allows you to access current and historical data. The API is paid via a simple pricing structure that allows you to embed our data into your applications.

https://securitytrails.com/app/account/credentials

\#\#\# Security Trails  
SECURIT\_TRAILS\_API Key=Tkl5RbGA1NGLy8nvTl9nQag76KuscaYc

\#\#\# Documentation  
https://docs.securitytrails.com/docs/overview

https://platform.securityscorecard.io/

Login  \= jim@planet9ventures.ai  
Password \= randomsecuritypassword100$R

\#\# API Documentation  
https://www.cvedetails.com/api/v1/swagger-ui/

CVEDETAILS\_API\_KEY=ff5521527e4d48673796981d96ffef2bf7f2fde7.eyJzdWIiOjc5OTMsImlhdCI6MTczMTQ2OTE4MiwiZXhwIjoxOTIzMjY0MDAwLCJraWQiOjEsImMiOiI0Nno3QWtZM2F5cStKNmJcL3JwTjBCXC9HZ21ETmhKaFEzZElXQllobDhvTmcrbWpsb3BtWnEybklLUzI2K2ZMNVwvOVp2T2x4V2UifQ==  
https://www.cvedetails.com/user/access-token/list

POPULATION\_EXPLORER\_API\_KEY=8ab2f7b3be38e2d24a617c5e0592c5e64394614d

https://prd-app.populationexplorer.com/index.html 

