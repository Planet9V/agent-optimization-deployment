# The Integrated Framework of Affective and Physiological Modulation in Clinical Music Therapy: ISO Principle, Hevner's Circle, and Gilboa's MAP

## I. Introduction: Contextualizing the Triad of Selection, Action, and Analysis

Music therapy (MT) is defined as the clinical and evidence-based use of music interventions designed to achieve individualized goals within a therapeutic relationship by a credentialed professional.^1^ The complexity of music and the subjective nature of individual responses necessitate systematic tools that bridge lived experience with quantifiable evidence. Professional standards mandate that music therapists strive for the highest level and quality of music involvement consistent with the client's functioning level, utilizing appropriate musical materials.^2^

This analysis details a tripartite methodology used in clinical practice: the ISO Principle, Hevner's Adjective Circle, and Gilboa's Music-therapy Analyzing Partitura (MAP). This integrated approach provides a rigorous framework for systematizing the criteria for musical selection (Hevner), executing the therapeutic action (ISO), and analyzing the session process (MAP).

## II. The ISO Principle: Theoretical Foundation and Clinical Mechanisms of Affective Shift

### Historical Development and Definitional Scope

The term "iso principle" is specific to the field of music therapy.^3^ It was first introduced by Altshuler in the late 1940s or early 1950s as a method of mood management that initially relied on a system of programmed classical music.^4^

The modern clinical definition encompasses a technique wherein music is first **matched** with the client's current mood or physiological state, and then **gradually altered** (or modulated) to effect a shift toward a desired state.^3^ This technique can be used to affect both emotional states and physiological responses, such as heart rate and blood pressure.^3^ The core philosophy of the ISO Principle is the crucial need to meet the client wherever they are at that current moment, validating their internal reality, which may manifest as psychological distress or physiological dysregulation.^4^

### Clinical Methodology: Matching and Guiding

The successful application of the ISO Principle follows two distinct clinical phases:

#### Phase 1: Matching the "Real" State (Iso-Adherence)

The initial phase requires the selection of music that is congruent with the patient's current mental pace, mood, or character of expression.^7^ For a client in a low-arousal or depressed state, the therapist would begin with slow, quiet, and contemplative music, as initiating with a loud, fast, or upbeat selection would be inappropriate or ineffective.^4^ Conversely, a patient experiencing a manic state would initially require matching with faster rhythms.^5^

A key clinical consideration is recognizing the highly personal and intimate relationships clients have with specific music; generalized "typical" emotion-evoking music is not universally effective.^3^ In practice, therapists often collaborate with the client to identify personalized music that expresses both their current mood and their desired future state, which then serve as the opposite ends of the therapeutic continuum.^4^

#### Phase 2: Guiding to the Desired State (Modulation)

Once a state of resonance is achieved, the therapist implements the guiding phase by progressively changing the musical stimulus.^4^ This modulation involves adjusting key musical elements, such as gradually increasing the tempo (getting faster), augmenting the dynamics (getting louder), building complexity, or enriching the timbre, to slowly transition the patient out of the current state.^5^ This systematic adjustment facilitates a shift in the patient’s internal experience.^5^

### Underlying Psychological and Physiological Theory

The primary underlying mechanism that gives the ISO Principle its persuasive force is  **musical entrainment** .^6^ Entrainment is the scientific observation that biological oscillators—including motor responses, heart rate, and respiratory patterns—tend to synchronize, or “lock,” to an external rhythmic cue.^9^

The initial matching phase establishes a  **common period entrainment** , where the auditory rhythm aligns with the client's internal rhythm.^9^ The subsequent, gradual modulation of the music's frequency, tempo, and other parameters acts to pull the client's internal state along the new trajectory.^9^ Research has shown that motor responses entrain instantaneously to a rhythmic stimulus, and this synchronization is maintained even when subtle tempo changes are introduced, validating the gradual alteration inherent in the ISO protocol.^9^

### Clinical Applications and Empirical Limitations

The ISO Principle is a well-known concept frequently referenced in music therapy literature.^8^ Clinical case studies support its application in mood management for clients with co-morbid psychiatric diagnoses.^4^ Furthermore, adherence to the ISO principle has been empirically shown to yield superior emotional therapeutic effects, specifically improving participant arousal levels when compared to non-adherence conditions.^12^ It has also been used successfully with women in childbirth.^5^

However, scholarly consensus is lacking on the precise bodily states and musical elements that define the ISO principle.^10^ Studies attempting to objectively measure physiological arousal shifts, such as via Galvanic Skin Response (GSR), have sometimes failed to show statistically significant differences between ISO-informed music and control conditions, even when participants’ subjective self-ratings indicated a perceived increase in arousal.^10^ This suggests a gap between subjective mood regulation and reliably measurable, profound physiological entrainment, highlighting the necessity for refined psychoacoustic categorization tools.

## III. Hevner's Adjective Circle: The Psychoacoustic Compass for Systematic Selection

Kate Hevner’s Adjective Circle is a classic psychometric tool that provides the theoretical framework for systematizing the emotion-music connection, which is vital for the systematic execution of the ISO Principle.

### Structure, Methodology, and Dimensions

Hevner’s seminal work, conducted in the 1930s, established predictable emotional responses to music.^13^ Her original methodology categorized 67 affective adjectives into eight distinct clusters, arranged in a circular fashion.^14^ This organizational schema aligns conceptually with the two fundamental dimensions of emotional experience: **valence** (pleasure/displeasure) and **arousal** (activation/deactivation).^16^ Adjoining clusters share common affective qualities, while opposing clusters represent sharp thematic contrasts.^15^

The framework has been widely used and updated. A subsequent revision by Schubert (2003), incorporating concepts from Russell’s circumplex model, refined the list to 46 words organized into nine clusters.^16^

### Correlation with Specific Musical Elements

Hevner’s experiments systematically associated emotional responses with six musical parameters: mode, tempo, pitch, rhythm, harmony, and melody.^14^ For instance, clear correlations were established between:

* **Mode and Valence:** Major scales are frequently associated with positive emotions (e.g., joy), while minor scales correlate with negative emotions (e.g., sadness).^16^
* **Pitch/Tempo and Arousal:** Specific musical parameters were found to be responsible for a particular emotional response.^13^

This systematic mapping dictates the precise path of the ISO trajectory. If a client is identified as being in an affective state corresponding to one cluster, Hevner’s framework guides the therapist to identify the specific musical parameters that must be manipulated to achieve a shift toward an adjoining category on the circle.^17^ The pedagogical value of the Adjective Circle is integral to music therapy training, serving as an entry point for students to explore how music evokes and changes emotions over time through active listening.^18^

### Generalizability and Critique

While widely used, the model faces critiques regarding cultural universality. Cross-cultural studies suggest that Westerners may prefer emotions of higher arousal than Easterners, indicating a potential cultural influence on emotional intensity ratings.^19^

## IV. Gilboa’s Music-therapy Analyzing Partitura (MAP): Documentation and Research Methodology

Gilboa’s Music-therapy Analyzing Partitura (MAP) was proposed to address the challenges of standardized documentation and rigorous analysis in music therapy sessions, particularly when tracking continuous processes like the ISO Principle's modulation phase.^20^

### The Rationale for Graphic Notation

MAP’s central objective is to offer a mechanism for describing complex musical and interactive processes that standard Western notation cannot adequately capture, especially in improvised or non-traditional contexts.^22^ By representing the temporal flow of the session in a spatial manner, akin to a musical score or  *Partitura* , MAP allows researchers and clinicians to apprehend the session as a whole, providing insight into the therapeutic process and assisting in clinical decision-making.^22^

### MAP Structure and Multidimensional Coding System

MAP utilizes a flexible coding system employing a mixed vocabulary of graphic, iconic, and indexical elements.^23^ This multidimensional notation is structured to capture various elements:

* **Musical Documentation:** It employs both standard notation and customized graphic symbols for describing improvised musical elements, such as dynamics, complexity, or timbre.^22^
* **Interactional Data:** The MAP extends beyond music to document interaction, including both verbal and non-verbal communication.^23^
  * **Verbal:** Topics of conversation are indexed with letters, often organized in a two-level hierarchy where primary themes are marked in bold.^23^
  * **Non-Verbal/Process:** Special iconic symbols can be introduced to represent unique session dynamics, such as arrows indicating a turn-taking game.^23^ It also incorporates photo icons of instruments used by the client and therapist.^23^

The capacity to integrate both musical and non-musical data enables high-resolution process analysis, allowing for the precise correlation of the therapist’s musical modulation (the ISO variable) against resulting behavioral and communicative shifts in the client.^23^ Adaptations of the core MAP system include the Sketch-MAP, the Song MAP, and the Dyad Music Analyzing Partitura (DMAP) for analyzing dyadic sessions.^21^

### Psychometric Validity and Usability

Empirical studies have confirmed MAP's significant utility as a research methodology tool.^21^ Music therapists (MTs), regardless of experience level, found the MAP code easy to understand.^20^ When analyzing sessions using MAP, MTs correctly answered significantly more informative questions compared to using verbal descriptions alone, and they indicated that MAP had better analyzing potential than qualitative written reports.^20^

## V. Synthesis: The Integrated Framework for Evidence-Based Practice

The efficacy of structured music therapy interventions is maximized when the theoretical selection guide (Hevner), the clinical protocol (ISO), and the analytical metric (MAP) are integrated into a singular system.

### The Interrelationship in Practice

1. **Selection (Hevner Informs ISO Matching):** Hevner’s framework provides the systematic criteria for categorizing the client's starting mood state (valence and arousal) and the desired end state.^16^ The therapist uses this psychoacoustic knowledge to ensure the initial selection of music for Iso-Adherence is not only personally resonant but also psychoacoustically calibrated to match the client's affective state, and that the trajectory follows an adjacent emotional path on the circle.^17^
2. **Intervention (ISO Execution):** The ISO Principle translates the Hevner-informed map into a kinetic intervention, using the entrainment mechanism to gradually shift musical parameters (tempo, dynamics, etc.) to pull the client along the defined affective trajectory.^5^
3. **Analysis (MAP Documentation):** MAP provides the empirical verification of the process. By visually mapping the sequence of musical adjustments (the modulation phase of ISO) against the concurrently documented client behavior, verbal processing themes, and non-verbal engagement, the therapist can definitively link specific musical changes to therapeutic outcomes.^23^ This high-resolution documentation is critical for future research aiming to objectively measure physiological arousal shifts during the ISO Principle.^10^

By adopting these integrated frameworks, music therapy can generate the precise empirical evidence necessary to fully validate the efficacy of the ISO Principle and its powerful neurophysiological effects.^11^
